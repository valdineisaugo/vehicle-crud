package com.example.vehiclecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleCrudApplication.class, args);
	}

}
