package com.example.vehiclecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
